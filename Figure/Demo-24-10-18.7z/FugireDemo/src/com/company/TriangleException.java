package com.company;

public class TriangleException extends Exception {
    public TriangleException() {
    }

    public TriangleException(String message) {
        super(message);
    }
}
