package com.company;

public interface Figure {
    boolean equal(Figure figure);
    void print();
}
